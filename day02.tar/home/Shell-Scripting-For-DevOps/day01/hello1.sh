#!/bin/bash
# This is script for me
echo "TWS: Hello dosto"
echo "Learners: Devops wale. hum to"
echo "TWS: tho, like"

