#!/bin/bash
<<     Notexecutable
This will not show.
Notexecutable

#echo "I will complete #90DaysOfDevOps challenge."
#echo  "what is you name:"
#read firstname
#echo "my name is $firstname"
#echo "First arguments: $1"
# echo "Second Argument: $2"

read -p "Pls enter first number: " i
read -p "Enter second number: " j
if [[ $i -gt $j ]];
	then
echo "$i is bigger than $j."
elif [[ $i -lt $j ]]; then
	echo "$j is bigger than $i."

else
	echo "The numbers are equal"
fi


