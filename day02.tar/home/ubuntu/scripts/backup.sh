#!/bin/bash
<< comment 
this script will take the backups
from source to target
comment

src_dir="/home/ubuntu/scripts"
tgt_dir="/home/ubuntu/backup"

backup_filename="backup_$(date +%Y-%m-%d-%H-%M-%s).tar.gz"
echo "backup started"
echo "backingup to $backup_filename.."

tar -czvf "${tgt_dir} ${backup_filename}" "$src_dir"
echo "Backup complete"


