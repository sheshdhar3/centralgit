#!/bin/bash

# Ye hai hamaare nibba nibbi ki kahani
echo "Nibba; kaisi ho :)"
echo "Nibbi: Chata kahyenga"
echo "Nibba: jo tum chaho"
echo "Nibbi: zara data dekho aaj ki"
date
echo "Nibba: mai kaise"
uptime
echo "Nibbi: files konse hai tumaare pass"
ls /home/ubuntu
echo "Nibba: shah jahan ne taj mahal bnvaya tha, mai folder naaunga"
# mkdir nibbi_ka_makbara

echo "Nibba: Tum kisse bbat kar rahi thi"
echo "Nibbi: vo tha"
read voh
echo " voh $voh hai"
echo "Nibba: But $voh toh $1 ka hai"
echo "Nibbi : tum itne sare ko kye laye"
echo "Nibba: bas $# itne hi toh hai"
echo $@
