#!/bin/bash
<< disclaimer  
This is a loyality test for Nibba
this test is done b nibbi
disclaimer

echo "hello nibba"
echo "kya tum issko dekhoge?"
read ladki
if [ $ladki == "nibbi" ]; then
	echo "nibba loyal hai"
else
	echo "NIBBA haat se ja chika hai"
fi


