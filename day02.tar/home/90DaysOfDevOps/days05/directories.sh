<< Day5
Day5 Devops

Day5
#First >$1 Argument is Folder name
#Second >$2 Argument is Start Range
#Third >$3 Argument is End Range

mkdir $1 
cd $1

for (( i = $2 ; i <= $3 ; i++ ));

do
	   

     mkdir $1$i

	done

